import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_xlsio/xlsio.dart' as xlsio;
import 'package:excel/excel.dart' as xl;

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class Requerimiento {
  DateTime fechaInicio;
  int code;
  String requirement;
  String status;
  String flujoActividad;
  String remarks;
  String folderName;
  String fechaComprometida;
  String powerAppsId;

  Requerimiento({
    required this.fechaInicio,
    required this.code,
    required this.requirement,
    required this.status,
    required this.flujoActividad,
    required this.remarks,
    required this.folderName,
    required this.fechaComprometida,
    required this.powerAppsId,
  });

  static DateTime _excelSerialToDateTime(num serial) {
    // Excel serial dates start at 1899-12-30
    final base = DateTime(1899, 12, 30);
    return base.add(Duration(days: serial.floor()));
  }

  factory Requerimiento.fromRow(List<dynamic> row) {
    // Expected order:
    // 0 Fecha Inicio, 1 Code, 2 Requirement, 3 Status, 4 FLUJO ACTIVIDAD,
    // 5 Remarks & Updates, 6 Folder Name, 7 Fecha Comprometida, 8 __PowerAppsId__
    DateTime dt = DateTime.now();
    final v0 = row.length > 0 ? row[0] : null;
    if (v0 is DateTime) {
      dt = v0;
    } else if (v0 is String) {
      dt = DateTime.tryParse(v0) ?? dt;
    } else if (v0 is num) {
      dt = _excelSerialToDateTime(v0);
    }

    int code = DateTime.now().millisecondsSinceEpoch;
    final v1 = row.length > 1 ? row[1] : null;
    if (v1 is int) code = v1;
    else if (v1 is num) code = v1.toInt();
    else if (v1 is String) code = int.tryParse(v1) ?? code;

    String str(dynamic v) => v == null ? '' : '$v';

    return Requerimiento(
      fechaInicio: dt,
      code: code,
      requirement: str(row.length > 2 ? row[2] : ''),
      status: str(row.length > 3 ? row[3] : ''),
      flujoActividad: str(row.length > 4 ? row[4] : ''),
      remarks: str(row.length > 5 ? row[5] : ''),
      folderName: str(row.length > 6 ? row[6] : ''),
      fechaComprometida: str(row.length > 7 ? row[7] : ''),
      powerAppsId: str(row.length > 8 ? row[8] : ''),
    );
  }

  List<Object?> toRow() => [
        fechaInicio,
        code,
        requirement,
        status,
        flujoActividad,
        remarks,
        folderName,
        fechaComprometida,
        powerAppsId,
      ];
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Requerimientos DRL Chile',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<Requerimiento> _items = [];
  String _filter = '';
  final dateFmt = DateFormat('yyyy-MM-dd HH:mm:ss');

  Future<void> _exportarExcel() async {
    final workbook = xlsio.Workbook();
    final sheet = workbook.worksheets[0];
    final headers = [
      'Fecha Inicio',
      'Code',
      'Requirement',
      'Status',
      'FLUJO ACTIVIDAD',
      'Remarks & Updates',
      'Folder Name',
      'Fecha Comprometida',
      '__PowerAppsId__'
    ];
    for (var i = 0; i < headers.length; i++) {
      sheet.getRangeByIndex(1, i + 1).setText(headers[i]);
    }

    for (var r = 0; r < _items.length; r++) {
      final it = _items[r];
      sheet.getRangeByIndex(r + 2, 1).setText(dateFmt.format(it.fechaInicio));
      sheet.getRangeByIndex(r + 2, 2).setNumber(it.code.toDouble());
      sheet.getRangeByIndex(r + 2, 3).setText(it.requirement);
      sheet.getRangeByIndex(r + 2, 4).setText(it.status);
      sheet.getRangeByIndex(r + 2, 5).setText(it.flujoActividad);
      sheet.getRangeByIndex(r + 2, 6).setText(it.remarks);
      sheet.getRangeByIndex(r + 2, 7).setText(it.folderName);
      sheet.getRangeByIndex(r + 2, 8).setText(it.fechaComprometida);
      sheet.getRangeByIndex(r + 2, 9).setText(it.powerAppsId);
    }

    final bytes = workbook.saveAsStream();
    workbook.dispose();

    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/requerimientos_export.xlsx');
    await file.writeAsBytes(bytes, flush: true);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Exportado: ${file.path}')),
      );
    }
  }

  Future<void> _importarExcel() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx'],
    );
    if (result == null || result.files.isEmpty) return;
    final path = result.files.single.path;
    if (path == null) return;

    try {
      final bytes = File(path).readAsBytesSync();
      final book = xl.Excel.decodeBytes(bytes);

      // Busca la hoja por nombre y si no existe, usa la primera.
      final targetSheetName = '01-INGRESO REQUERIMIENTO';
      xl.Sheet sheet;
      if (book.tables.containsKey(targetSheetName)) {
        sheet = book.tables[targetSheetName]!;
      } else {
        final first = book.tables.keys.isNotEmpty ? book.tables.keys.first : null;
        if (first == null) throw Exception('No se encontraron hojas en el Excel.');
        sheet = book.tables[first]!;
      }

      if (sheet.maxRows <= 1) {
        throw Exception('La hoja no contiene datos suficientes.');
      }

      // Detecta encabezados en la primera fila
      final headerRow = sheet.row(0).map((c) => c?.value?.toString().trim() ?? '').toList();
      // Lista de índices según encabezados esperados (flexible ante mínimos cambios de nombre)
      int colIndex(String nameFallback, List<String> aliases) {
        final idx = headerRow.indexWhere((h) => aliases.any((a) => h.toLowerCase() == a.toLowerCase()));
        return idx >= 0 ? idx : -1;
      }

      final idxFechaIni = colIndex('Fecha Inicio', ['Fecha Inicio']);
      final idxCode = colIndex('Code', ['Code','Código','Cod']);
      final idxReq = colIndex('Requirement', ['Requirement','Requerimiento']);
      final idxStatus = colIndex('Status', ['Status','Estado']);
      final idxFlujo = colIndex('FLUJO ACTIVIDAD', ['FLUJO ACTIVIDAD','Flujo','Flujo Actividad']);
      final idxRemarks = colIndex('Remarks & Updates', ['Remarks & Updates','Observaciones','Remarks']);
      final idxFolder = colIndex('Folder Name', ['Folder Name','Carpeta']);
      final idxFechaComp = colIndex('Fecha Comprometida', ['Fecha Comprometida','Fecha Comp']);
      final idxPower = colIndex('__PowerAppsId__', ['__PowerAppsId__','PowerAppsId']);

      List<Requerimiento> nuevos = [];
      for (var r = 1; r < sheet.maxRows; r++) {
        List<dynamic> row = List.filled(9, null);
        List<xl.Data?> raw = sheet.row(r);

        dynamic valAt(int idx) => (idx >= 0 && idx < raw.length) ? raw[idx]?.value : null;

        row[0] = valAt(idxFechaIni);
        row[1] = valAt(idxCode);
        row[2] = valAt(idxReq);
        row[3] = valAt(idxStatus);
        row[4] = valAt(idxFlujo);
        row[5] = valAt(idxRemarks);
        row[6] = valAt(idxFolder);
        row[7] = valAt(idxFechaComp);
        row[8] = valAt(idxPower);

        nuevos.add(Requerimiento.fromRow(row));
      }

      setState(() {
        _items
          ..clear()
          ..addAll(nuevos);
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Importados ${nuevos.length} registros.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al importar: $e')),
        );
      }
    }
  }

  void _agregar() async {
    final nuevo = await Navigator.push<Requerimiento>(
      context,
      MaterialPageRoute(builder: (_) => const FormPage()),
    );
    if (nuevo != null) {
      setState(() => _items.add(nuevo));
    }
  }

  void _editar(int index) async {
    final editado = await Navigator.push<Requerimiento>(
      context,
      MaterialPageRoute(builder: (_) => FormPage(data: _items[index])),
    );
    if (editado != null) {
      setState(() => _items[index] = editado);
    }
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _items.where((e) {
      final q = _filter.toLowerCase();
      return q.isEmpty ||
          e.requirement.toLowerCase().contains(q) ||
          e.status.toLowerCase().contains(q) ||
          e.folderName.toLowerCase().contains(q);
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Requerimientos DRL Chile'),
        actions: [
          IconButton(
            onPressed: _exportarExcel,
            icon: const Icon(Icons.download),
            tooltip: 'Exportar a Excel',
          ),
          IconButton(
            onPressed: _importarExcel,
            icon: const Icon(Icons.upload),
            tooltip: 'Importar desde Excel',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              decoration: const InputDecoration(
                labelText: 'Buscar por texto (Requirement/Status/Folder)',
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (v) => setState(() => _filter = v),
            ),
          ),
          Expanded(
            child: ListView.separated(
              itemCount: filtered.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, index) {
                final r = filtered[index];
                final idx = _items.indexOf(r);
                return ListTile(
                  title: Text(r.requirement.isEmpty ? '(Sin título)' : r.requirement),
                  subtitle: Text('${r.status} • ${DateFormat('yyyy-MM-dd').format(r.fechaInicio)}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () => _editar(idx),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _agregar,
        icon: const Icon(Icons.add),
        label: const Text('Nuevo requerimiento'),
      ),
    );
  }
}

class FormPage extends StatefulWidget {
  final Requerimiento? data;
  const FormPage({super.key, this.data});

  @override
  State<FormPage> createState() => _FormPageState();
}

class _FormPageState extends State<FormPage> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController requirement;
  late TextEditingController status;
  late TextEditingController flujo;
  late TextEditingController remarks;
  late TextEditingController folder;
  late TextEditingController fechaComp;
  DateTime fechaInicio = DateTime.now();

  @override
  void initState() {
    super.initState();
    requirement = TextEditingController(text: widget.data?.requirement ?? '');
    status = TextEditingController(text: widget.data?.status ?? 'EN CURSO');
    flujo = TextEditingController(text: widget.data?.flujoActividad ?? '');
    remarks = TextEditingController(text: widget.data?.remarks ?? '');
    folder = TextEditingController(text: widget.data?.folderName ?? '');
    fechaComp = TextEditingController(text: widget.data?.fechaComprometida ?? '');
    fechaInicio = widget.data?.fechaInicio ?? DateTime.now();
  }

  @override
  void dispose() {
    requirement.dispose();
    status.dispose();
    flujo.dispose();
    remarks.dispose();
    folder.dispose();
    fechaComp.dispose();
    super.dispose();
  }

  void _guardar() {
    if (_formKey.currentState!.validate()) {
      final item = Requerimiento(
        fechaInicio: fechaInicio,
        code: widget.data?.code ?? DateTime.now().millisecondsSinceEpoch,
        requirement: requirement.text,
        status: status.text,
        flujoActividad: flujo.text,
        remarks: remarks.text,
        folderName: folder.text,
        fechaComprometida: fechaComp.text,
        powerAppsId: widget.data?.powerAppsId ?? '',
      );
      Navigator.pop(context, item);
    }
  }

  Future<void> _pickFecha() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: fechaInicio,
      firstDate: DateTime(2010),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() => fechaInicio = picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.data == null ? 'Nuevo requerimiento' : 'Editar requerimiento')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: requirement,
                decoration: const InputDecoration(labelText: 'Requirement'),
                validator: (v) => (v == null || v.isEmpty) ? 'Ingrese el requerimiento' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: status,
                decoration: const InputDecoration(labelText: 'Status'),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: flujo,
                decoration: const InputDecoration(labelText: 'FLUJO ACTIVIDAD'),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: remarks,
                decoration: const InputDecoration(labelText: 'Remarks & Updates'),
                maxLines: 3,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: folder,
                decoration: const InputDecoration(labelText: 'Folder Name'),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: fechaComp,
                decoration: const InputDecoration(labelText: 'Fecha Comprometida'),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: Text('Fecha Inicio: ${DateFormat('yyyy-MM-dd').format(fechaInicio)}')),
                  TextButton.icon(onPressed: _pickFecha, icon: const Icon(Icons.date_range), label: const Text('Cambiar')),
                ],
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: _guardar,
                icon: const Icon(Icons.save),
                label: const Text('Guardar'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}