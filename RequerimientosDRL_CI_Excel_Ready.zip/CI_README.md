# CI/CD de APK (GitHub Actions + Importación Excel activa)

- APK debug siempre disponible como artefacto.
- APK release firmado si configuras los secretos del keystore.
- Importación de Excel habilitada con el paquete `excel`.